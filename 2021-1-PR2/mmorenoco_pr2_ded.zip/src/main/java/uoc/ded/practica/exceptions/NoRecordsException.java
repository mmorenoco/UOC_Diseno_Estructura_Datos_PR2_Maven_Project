package uoc.ded.practica.exceptions;

public class NoRecordsException extends DEDException {
	private static final long serialVersionUID = 7841967761678930444L;
}
