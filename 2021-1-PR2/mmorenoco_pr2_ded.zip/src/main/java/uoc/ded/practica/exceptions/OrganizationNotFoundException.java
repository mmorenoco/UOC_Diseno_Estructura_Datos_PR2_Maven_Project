package uoc.ded.practica.exceptions;

public class OrganizationNotFoundException extends DEDException {
	private static final long serialVersionUID = 2355117047423456797L;
}
