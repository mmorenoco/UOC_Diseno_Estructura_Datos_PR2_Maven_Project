package uoc.ded.practica.exceptions;

public class UserNotInActivityException extends DEDException {
	private static final long serialVersionUID = 1542368660447023001L;
}
