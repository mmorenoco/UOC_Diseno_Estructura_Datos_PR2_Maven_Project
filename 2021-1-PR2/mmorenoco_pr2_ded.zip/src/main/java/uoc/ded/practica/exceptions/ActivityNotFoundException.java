package uoc.ded.practica.exceptions;

public class ActivityNotFoundException extends DEDException {
	private static final long serialVersionUID = -3785739226163517082L;
}
