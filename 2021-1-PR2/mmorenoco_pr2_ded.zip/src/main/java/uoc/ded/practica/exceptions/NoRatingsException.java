package uoc.ded.practica.exceptions;

public class NoRatingsException extends DEDException {
	private static final long serialVersionUID = 5142103048998336814L;
}
