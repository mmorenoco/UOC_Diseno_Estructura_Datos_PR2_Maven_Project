package uoc.ded.practica.exceptions;

public class NoActivitiesException extends DEDException {
	private static final long serialVersionUID = 3307485512156738271L;
}
