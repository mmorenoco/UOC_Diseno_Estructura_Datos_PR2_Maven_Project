package uoc.ded.practica.exceptions;

public class OrderNotFoundException extends DEDException {
    private static final long serialVersionUID = 2515739226163517082L;
}
