package uoc.ded.practica.exceptions;

public class GroupNotFoundException extends DEDException {
    private static final long serialVersionUID = 5699739226163517082L;
}
