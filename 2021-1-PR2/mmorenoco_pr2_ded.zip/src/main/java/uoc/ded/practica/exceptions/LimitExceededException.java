package uoc.ded.practica.exceptions;

public class LimitExceededException extends DEDException {
	private static final long serialVersionUID = -6285846073831203948L;
}
