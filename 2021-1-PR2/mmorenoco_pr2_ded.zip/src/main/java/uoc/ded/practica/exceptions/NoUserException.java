package uoc.ded.practica.exceptions;

public class NoUserException extends DEDException {
    private static final long serialVersionUID = 2585739226163517082L;
}
